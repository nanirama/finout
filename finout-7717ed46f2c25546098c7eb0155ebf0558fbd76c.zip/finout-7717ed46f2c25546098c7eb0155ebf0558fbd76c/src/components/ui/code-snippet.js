import * as React from "react"

const CodeSnippet = ({ children }) => {
  return <pre>{children}</pre>
}

export default CodeSnippet
