# Finout Marketing Website

**Local Development.**

```shell
cd finout/
yarn start

# If you're using npm
npm run start
```
